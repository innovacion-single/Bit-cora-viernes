# Bitácora de Viernes — guía de instalación

La página vive en Vercel y los datos se guardan en Supabase. El historial no depende del navegador: se conserva aunque cambies de equipo o borres cookies.

## Qué hay en esta carpeta

| Archivo | Para qué sirve |
| --- | --- |
| `index.html` | La bitácora con el diseño Single |
| `api/proyectos.js` | Función de Vercel que lee y guarda en Supabase |
| `supabase.sql` | Crea la tabla donde se guardan los proyectos |
| `package.json` | Le dice a Vercel qué librería instalar |

## 1. Crear la base en Supabase

1. Entra a supabase.com y crea una cuenta (el plan gratuito alcanza).
2. Crea un proyecto nuevo. Elige la región más cercana a México (por ejemplo, us-east o us-west) y guarda la contraseña de la base en un lugar seguro.
3. Ve a **SQL Editor > New query**, pega el contenido de `supabase.sql` y pulsa **Run**.
4. Ve a **Project Settings > API** (o **API Keys**) y copia dos datos:
   - **Project URL** (algo como `https://xxxx.supabase.co`)
   - La **clave secreta**: `service_role` o `secret key`. **No** uses la `anon` / `publishable`.

> La clave secreta da acceso total a la base. Solo se pega en Vercel; nunca en el código ni en GitHub.

## 2. Subir el código a GitHub

1. Crea un repositorio nuevo (privado) en GitHub, por ejemplo `bitacora-de-viernes`.
2. Sube los archivos de esta carpeta tal cual, respetando la carpeta `api/`.

## 3. Publicar en Vercel

1. En Vercel: **Add New > Project** y elige el repositorio.
2. Framework Preset: **Other**. No cambies nada más.
3. Antes de pulsar Deploy, abre **Environment Variables** y agrega:

| Nombre | Valor |
| --- | --- |
| `SUPABASE_URL` | El Project URL de Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | La clave secreta de Supabase |
| `CLAVE_EQUIPO` | La contraseña que usará tu equipo para entrar (invéntala) |

4. Pulsa **Deploy**. Al terminar, Vercel te da la liga de la bitácora.

Si ya hiciste el deploy sin las variables, agrégalas en **Settings > Environment Variables** y luego ve a **Deployments > ⋯ > Redeploy**.

## 4. Usarla

- Abre la liga, escribe la `CLAVE_EQUIPO` y listo. La clave se recuerda en ese navegador.
- Para cambiar la clave: edita `CLAVE_EQUIPO` en Vercel y haz Redeploy. Todos tendrán que volver a escribirla.
- Los cambios de otros usuarios aparecen solos cada 30 segundos o al volver a la pestaña.

## Respaldos

En Supabase, **Table Editor > proyectos > Export to CSV** descarga todo el historial cuando quieras.

## Si algo falla

| Mensaje | Causa probable |
| --- | --- |
| "No se pudo conectar. Revisa la configuración en Vercel." | Faltan las variables de entorno o no se hizo Redeploy |
| "Clave incorrecta." | La clave no coincide con `CLAVE_EQUIPO` |
| Los proyectos no se guardan | La tabla no existe: vuelve a correr `supabase.sql` |

En Vercel, **Deployments > (el último) > Logs** muestra el detalle del error.
