import { createClient } from "@supabase/supabase-js";

// Variables de entorno (se configuran en Vercel > Settings > Environment Variables)
const SUPABASE_URL = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
const CLAVE_EQUIPO = process.env.CLAVE_EQUIPO;

const supabase = SUPABASE_URL && SUPABASE_KEY
  ? createClient(SUPABASE_URL, SUPABASE_KEY, { auth: { persistSession: false } })
  : null;

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");

  if (!supabase || !CLAVE_EQUIPO) {
    return res.status(500).json({ error: "Faltan variables de entorno en Vercel." });
  }
  if (req.headers["x-clave"] !== CLAVE_EQUIPO) {
    return res.status(401).json({ error: "Clave incorrecta." });
  }

  try {
    if (req.method === "GET") {
      const { data, error } = await supabase
        .from("proyectos")
        .select("id, data, updated_at")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === "PUT") {
      const { id, data } = req.body || {};
      if (!id || typeof data !== "object" || data === null) {
        return res.status(400).json({ error: "Faltan datos del proyecto." });
      }
      const { error } = await supabase
        .from("proyectos")
        .upsert({ id, data, updated_at: new Date().toISOString() });
      if (error) throw error;
      return res.status(204).end();
    }

    if (req.method === "DELETE") {
      const id = req.query.id;
      if (!id) return res.status(400).json({ error: "Falta el id." });
      const { error } = await supabase.from("proyectos").delete().eq("id", id);
      if (error) throw error;
      return res.status(204).end();
    }

    res.setHeader("Allow", "GET, PUT, DELETE");
    return res.status(405).end();
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Error al conectar con Supabase." });
  }
}
