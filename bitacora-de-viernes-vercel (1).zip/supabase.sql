-- Ejecuta este script una sola vez en Supabase > SQL Editor > New query > Run

create table if not exists public.proyectos (
  id          text primary key,
  data        jsonb not null,
  updated_at  timestamptz not null default now()
);

-- Seguridad: nadie puede leer ni escribir directo desde internet.
-- Solo la función de Vercel (con la clave secreta) tiene acceso.
alter table public.proyectos enable row level security;
