import { createClient } from "@supabase/supabase-js";

// Diagnóstico: abre https://TU-SITIO.vercel.app/api/estado
// No muestra ninguna clave, solo si están configuradas y si funcionan.
function tipoDeClave(k) {
  if (!k) return "falta";
  if (k.startsWith("sb_secret_")) return "secret (correcta)";
  if (k.startsWith("sb_publishable_")) return "publishable (INCORRECTA: usa la secret)";
  try {
    const payload = JSON.parse(Buffer.from(k.split(".")[1], "base64url").toString());
    if (payload.role === "service_role") return "service_role (correcta)";
    if (payload.role === "anon") return "anon (INCORRECTA: usa la service_role)";
    return "desconocida (rol: " + payload.role + ")";
  } catch {
    return "no reconocida (revisa que la copiaste completa, sin espacios)";
  }
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  const r = {
    SUPABASE_URL: url ? (url.startsWith("https://") && url.includes(".supabase.co") ? "configurada" : "configurada, pero no parece un Project URL: " + url.slice(0, 40)) : "falta",
    SUPABASE_SERVICE_ROLE_KEY: tipoDeClave(key && key.trim()),
    CLAVE_EQUIPO: process.env.CLAVE_EQUIPO ? "configurada" : "falta",
    espacios_en_la_clave: key && key !== key.trim() ? "SÍ: borra los espacios al inicio o final" : "no",
  };

  if (url && key) {
    const sb = createClient(url, key.trim(), { auth: { persistSession: false } });
    const leer = await sb.from("proyectos").select("id").limit(1);
    r.leer_tabla = leer.error ? "ERROR: " + leer.error.message : "ok";
    const id = "__prueba__";
    const escribir = await sb.from("proyectos").upsert({ id, data: { prueba: true } });
    r.guardar_en_tabla = escribir.error ? "ERROR: " + escribir.error.message : "ok";
    if (!escribir.error) await sb.from("proyectos").delete().eq("id", id);
  }

  const ok = Object.values(r).every(v => !/falta|INCORRECTA|ERROR|SÍ|no reconocida|no parece/.test(v));
  r.resultado = ok ? "Todo bien: la bitácora debería guardar." : "Hay un problema: revisa las líneas marcadas.";
  res.status(200).json(r);
}
